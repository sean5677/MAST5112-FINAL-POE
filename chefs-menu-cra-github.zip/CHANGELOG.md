# Changelog

## 1.0.0 - Initial
- Complete CRA + TypeScript project
- LocalStorage persistence
- Clean modern styling (index.css)
- README and CHANGELOG included
- GitHub Actions CI and testing added
