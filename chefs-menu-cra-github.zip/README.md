# chefs-menu-app

Chef's Menu App — Create React App + TypeScript.

Repository: https://github.com/ST10493359/chefs-menu-app

## Features
- Add / remove menu items
- Filter by course (Starter, Main, Dessert)
- Average price per course
- Persistent storage using `localStorage`
- Clean, modern CSS styling

## Setup
1. Clone: `git clone https://github.com/ST10493359/chefs-menu-app.git`
2. `cd chefs-menu-app`
3. `npm install`
4. `npm start`

## CI
This repo includes a GitHub Actions workflow `.github/workflows/ci.yml` to run tests and build on push/pull requests.

## Tests
Run `npm test` to execute the React Testing Library tests.

