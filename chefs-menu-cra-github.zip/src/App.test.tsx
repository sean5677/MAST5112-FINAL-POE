import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders app title', () => {
  render(<App />);
  const el = screen.getByText(/Chef's Menu App/i);
  expect(el).toBeInTheDocument();
});
