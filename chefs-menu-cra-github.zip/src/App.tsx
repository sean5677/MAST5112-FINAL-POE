import React, { useEffect, useState } from "react";
import Home from "./pages/Home";
import ManageMenu from "./pages/ManageMenu";
import FilterMenu from "./pages/FilterMenu";
import { MenuItem } from "./types";

type Page = "home" | "manage" | "filter";

const STORAGE_KEY = "chefs_menu_items_v1";

const App: React.FC = () => {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [page, setPage] = useState<Page>("home");

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as MenuItem[];
        setMenuItems(parsed);
      }
    } catch (e) {
      console.error("Failed to load from localStorage", e);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(menuItems));
    } catch (e) {
      console.error("Failed to save to localStorage", e);
    }
  }, [menuItems]);

  const addMenuItem = (item: MenuItem) => {
    setMenuItems((prev) => [...prev, item]);
  };

  const removeMenuItem = (id: string) => {
    setMenuItems((prev) => prev.filter((it) => it.id !== id));
  };

  return (
    <div className="app">
      <header className="header">
        <div>
          <h1>Chef's Menu App</h1>
          <div className="small-muted">Create. Manage. Share your menu.</div>
        </div>
        <div>
          <small className="small-muted">CRA + TypeScript</small>
        </div>
      </header>

      <div className="card" style={{marginBottom:16}}>
        <nav className="nav">
          <button className={page==="home"?"active":""} onClick={() => setPage("home")}>Home</button>
          <button className={page==="manage"?"active":""} onClick={() => setPage("manage")}>Manage</button>
          <button className={page==="filter"?"active":""} onClick={() => setPage("filter")}>Filter</button>
        </nav>
      </div>

      <main>
        {page === "home" && <Home menuItems={menuItems} />}
        {page === "manage" && (
          <ManageMenu menuItems={menuItems} addItem={addMenuItem} removeItem={removeMenuItem} />
        )}
        {page === "filter" && <FilterMenu menuItems={menuItems} />}
      </main>
    </div>
  );
};

export default App;
