import React, { useState } from "react";
import { MenuItem, Course } from "../types";

interface Props { menuItems: MenuItem[] }

const FilterMenu: React.FC<Props> = ({ menuItems }) => {
  const [filter, setFilter] = useState<Course>("Starter");
  const filtered = menuItems.filter(m => m.course === filter);

  return (
    <section>
      <div className="card">
        <h2>Filter Menu</h2>
        <div style={{marginTop:8, marginBottom:12}}>
          <label>
            Show:
            <select value={filter} onChange={e=>setFilter(e.target.value as Course)} style={{marginLeft:8}}>
              <option value="Starter">Starter</option>
              <option value="Main">Main</option>
              <option value="Dessert">Dessert</option>
            </select>
          </label>
        </div>

        {filtered.length === 0 ? (
          <p className="small-muted">No items for {filter}.</p>
        ) : (
          <div className="menu-list">
            {filtered.map(it => (
              <div key={it.id} className="menu-item">
                <div>
                  <div style={{fontWeight:700}}>{it.dishName}</div>
                  <div className="small-muted">{it.description}</div>
                </div>
                <div style={{textAlign:"right"}}>R{it.price.toFixed(2)}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default FilterMenu;
