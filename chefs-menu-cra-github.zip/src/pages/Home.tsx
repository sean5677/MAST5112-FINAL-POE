import React from "react";
import { MenuItem, Course } from "../types";

interface Props { menuItems: MenuItem[] }
const COURSES: Course[] = ["Starter","Main","Dessert"];

const Home: React.FC<Props> = ({ menuItems }) => {
  const averages = COURSES.map(course => {
    const items = menuItems.filter(i => i.course === course);
    const avg = items.length ? items.reduce((s, it) => s + it.price, 0) / items.length : 0;
    return { course, avg };
  });

  return (
    <section>
      <div className="card">
        <h2>Menu Overview</h2>
        {menuItems.length === 0 ? (
          <p className="small-muted">No menu items yet. Add items in Manage.</p>
        ) : (
          <>
            <div style={{display:"flex", gap:16, marginTop:12}}>
              {averages.map(a => (
                <div key={a.course} className="card" style={{padding:12, minWidth:140}}>
                  <div className="small-muted">{a.course}</div>
                  <div style={{fontSize:18, fontWeight:700}}>R{a.avg.toFixed(2)}</div>
                </div>
              ))}
            </div>

            <div style={{marginTop:14}} className="card">
              <h3>Full Menu</h3>
              <div className="menu-list">
                {menuItems.map(it => (
                  <div key={it.id} className="menu-item">
                    <div>
                      <div style={{fontWeight:700}}>{it.dishName} <span className="small-muted">({it.course})</span></div>
                      <div className="small-muted">{it.description}</div>
                    </div>
                    <div style={{textAlign:"right"}}>
                      <div style={{fontWeight:700}}>R{it.price.toFixed(2)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </section>
  );
};

export default Home;
