import React, { useState } from "react";
import { MenuItem, Course } from "../types";

interface Props {
  menuItems: MenuItem[];
  addItem: (item: MenuItem) => void;
  removeItem: (id: string) => void;
}

const ManageMenu: React.FC<Props> = ({ menuItems, addItem, removeItem }) => {
  const [dishName, setDishName] = useState("");
  const [description, setDescription] = useState("");
  const [course, setCourse] = useState<Course>("Starter");
  const [price, setPrice] = useState("");

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dishName.trim() || !description.trim() || !price.trim()) {
      alert("Please fill all fields");
      return;
    }
    const parsed = Number(price);
    if (Number.isNaN(parsed) || parsed < 0) {
      alert("Price must be a valid non-negative number");
      return;
    }
    const newItem: MenuItem = {
      id: String(Date.now()) + Math.random().toString(36).slice(2,8),
      dishName: dishName.trim(),
      description: description.trim(),
      course,
      price: parsed
    };
    addItem(newItem);
    setDishName(""); setDescription(""); setPrice(""); setCourse("Starter");
  };

  return (
    <section>
      <div className="card">
        <h2>Manage Menu</h2>

        <form onSubmit={handleAdd} style={{marginTop:12}}>
          <div className="form-grid">
            <input className="full" placeholder="Dish name" value={dishName} onChange={e=>setDishName(e.target.value)} />
            <input placeholder="Price (e.g. 45.00)" value={price} onChange={e=>setPrice(e.target.value)} />
            <select value={course} onChange={e=>setCourse(e.target.value as Course)}>
              <option value="Starter">Starter</option>
              <option value="Main">Main</option>
              <option value="Dessert">Dessert</option>
            </select>
            <textarea className="full" placeholder="Description" value={description} onChange={e=>setDescription(e.target.value)} />
          </div>

          <div style={{marginTop:10, display:"flex", gap:8}}>
            <button type="submit" className="primary">Add Item</button>
          </div>
        </form>

        <div style={{marginTop:16}}>
          <h3>Current Items</h3>
          {menuItems.length === 0 ? <p className="small-muted">No items yet.</p> :
            <div className="menu-list">
              {menuItems.map(it => (
                <div key={it.id} className="menu-item">
                  <div>
                    <div style={{fontWeight:700}}>{it.dishName} <span className="small-muted">({it.course})</span></div>
                    <div className="small-muted">{it.description}</div>
                  </div>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontWeight:700}}>R{it.price.toFixed(2)}</div>
                    <div style={{marginTop:8}}>
                      <button onClick={()=>removeItem(it.id)}>Remove</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          }
        </div>
      </div>
    </section>
  );
};

export default ManageMenu;
